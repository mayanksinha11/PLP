package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.BookingDetails;
import com.cg.entities.Users;
import com.cg.service.IBookingService;

@Controller
public class BookingController {

	@Autowired
	IBookingService service;
	
	public IBookingService getService() {
		return service;
	}
	public void setService(IBookingService service) {
		this.service = service;
	}
	@RequestMapping("login")
	public String validateUser(Model model){
		Users user=new Users();
		model.addAttribute("user",user);
		return "Login";
	}
	@RequestMapping("loginAction")
	public String loginRedirect(Model model,@ModelAttribute("user") Users user)
	{
		Users u=service.validateUser(user.getMobileNo(), user.getPassword());
		model.addAttribute("validated", u);
		return "Success";
	}
	
	@RequestMapping("register")
	public String registerRedirect(Model model)
	{
		Users user=new Users();
		model.addAttribute("register", user);
		return "Register";
	}
	
	@RequestMapping("registerAction")
	public String addUser(Model model,@ModelAttribute("register") Users user)
	{
		Users u=service.addUser(user);
		model.addAttribute("user",u);
		return "Login";
	}
	
	
	@RequestMapping("bookingAction")
	public String addbooking(Model model,@ModelAttribute("booking") BookingDetails booking)
	{
		BookingDetails booking1=service.addBookingDetails(booking);
		model.addAttribute("booking",booking);
		return "Success";
	}
	
}
