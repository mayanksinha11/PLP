package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.BookingDetails;
import com.cg.entities.Hotel;
import com.cg.entities.RoomDetails;
import com.cg.entities.Users;
@Repository
public class BookingDAOImpl implements IBookingDAO{
   
	@PersistenceContext
   EntityManager manager;

	
	public EntityManager getManager() {
	return manager;
}

public void setManager(EntityManager manager) {
	this.manager = manager;
}

	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		System.out.println("In Service");
		manager.persist(user);
		return user;
	}

	@Override
	public Users validateUser(String mobileNo, String password) {
		 String query="select user from hUsers user where user.mobileNo=:m and user.password=:p";
		TypedQuery<Users> tquery=manager.createQuery(query, Users.class);
		tquery.setParameter("m", mobileNo);
		tquery.setParameter("p", password);
		Users u=tquery.getSingleResult();
		return u;
	}

	@Override
	public List<Hotel> viewAllHotels() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RoomDetails> getAllRooms(String hotelId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addBookingDetails(BookingDetails booking) {
		// TODO Auto-generated method stub
		manager.persist(booking);
		return booking.getBookingId();
	}

	@Override
	public BookingDetails viewBookingDetails(String bookingId) {
		// TODO Auto-generated method stub
		return null;
	}

}
