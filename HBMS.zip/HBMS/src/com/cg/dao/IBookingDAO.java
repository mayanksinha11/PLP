package com.cg.dao;

import java.util.List;

import com.cg.entities.BookingDetails;
import com.cg.entities.Hotel;
import com.cg.entities.RoomDetails;
import com.cg.entities.Users;

public interface IBookingDAO {
	public Users addUser(Users user);
	public Users validateUser(String mobileNo,String password);
	public List<Hotel> viewAllHotels();
	public List<RoomDetails> getAllRooms(String hotelId);
	public String addBookingDetails(BookingDetails booking);
    public BookingDetails viewBookingDetails(String bookingId);
}
