package com.cg.hrb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hrb.dao.IBookingDao;
import com.cg.hrb.entity.BookingDetails;
import com.cg.hrb.entity.HotelDetails;

@Service
@Transactional
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDao bdao;
	@Override
	public long insertBookingDetails(BookingDetails book) {
		// TODO Auto-generated method stub
		return bdao.insertBookingDetails(book);
	}

	@Override
	public List<HotelDetails> getAllHotels() {
		// TODO Auto-generated method stub
		return bdao.getAllHotels();
	}

}
